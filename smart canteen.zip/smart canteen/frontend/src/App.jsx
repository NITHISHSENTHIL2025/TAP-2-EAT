import { useState } from "react";
import Login from "./Login";
import OwnerLogin from "./OwnerLogin";
import Menu from "./Menu";

function App() {
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [role, setRole] = useState(localStorage.getItem("role"));
  const [mode, setMode] = useState(null);

  if (!token && !mode) {
    return (
      <div style={{ textAlign: "center", marginTop: "100px" }}>
        <h2>Smart Canteen</h2>
        <button onClick={() => setMode("student")}>
          Login as Student
        </button>
        <br /><br />
        <button onClick={() => setMode("owner")}>
          Login as Owner
        </button>
      </div>
    );
  }

  if (!token && mode === "student") {
    return <Login setToken={setToken} setRole={setRole} />;
  }

  if (!token && mode === "owner") {
    return <OwnerLogin setToken={setToken} setRole={setRole} />;
  }

  return <Menu token={token} role={role} setToken={setToken} />;
}

export default App;