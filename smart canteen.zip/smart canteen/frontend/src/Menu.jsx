import { useEffect, useState } from "react";

function Menu({ token, role, setToken }) {
  const [menu, setMenu] = useState([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/menu", {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
      .then(res => res.json())
      .then(data => setMenu(data));
  }, [token]);

  const logout = () => {
    localStorage.clear();
    setToken(null);
  };

  const addMenuItem = async () => {
    const res = await fetch("http://localhost:5000/add-menu", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ name, price })
    });

    const data = await res.json();

    if (res.ok) {
      alert("Menu item added");
      window.location.reload();
    } else {
      alert(data.message);
    }
  };

  return (
    <div style={{ padding: "40px", background: "#f5f5f7", minHeight: "100vh" }}>
      <h2>Smart Canteen Menu</h2>
      <button onClick={logout}>Logout</button>

      {role === "admin" && (
        <div style={{
          marginTop: "30px",
          padding: "20px",
          background: "#fff",
          borderRadius: "12px"
        }}>
          <h3>Add Menu Item</h3>

          <input
            placeholder="Item name"
            value={name}
            onChange={e => setName(e.target.value)}
          />
          <br /><br />

          <input
            placeholder="Price"
            value={price}
            onChange={e => setPrice(e.target.value)}
          />
          <br /><br />

          <button onClick={addMenuItem}>
            Add Item
          </button>
        </div>
      )}

      <div style={{ marginTop: "40px" }}>
        {menu.length === 0 ? (
          <p>No items available</p>
        ) : (
          menu.map(item => (
            <div key={item.id} style={{
              background: "#fff",
              padding: "15px",
              marginBottom: "10px",
              borderRadius: "10px"
            }}>
              {item.name} — ₹{item.price}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Menu;